
Cloud Chamber - v8 Scratch training with augmentation and preprocessing
==============================

This dataset was exported via roboflow.ai on March 9, 2022 at 1:41 PM GMT

It includes 35 images.
Trails are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise


