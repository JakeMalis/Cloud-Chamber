
Cloud Chamber - v9 Raw export dataset
==============================

This dataset was exported via roboflow.ai on March 17, 2022 at 6:31 PM GMT

It includes 17 images.
Trails are annotated in Pascal VOC format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


