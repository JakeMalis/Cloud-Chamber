
Cloud Chamber Particle Detection - v1 20210720 1115am
==============================

This dataset was exported via roboflow.ai on July 20, 2021 at 3:17 PM GMT

It includes 37 images.
Tracks are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Random rotation of between -15 and +15 degrees


